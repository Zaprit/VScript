# VScript SDK

## About
This is the software development kit for VScript 1.0 Cinnamon with this you can start tu use VScript


## How to develop
Now that you have the SDK you can get started developing.
Look inside the SDK folder and you will see this:
  Tools -- VRamen, appinfo, etc stuff to develop with
    | vramen -- the vscript compiler.
    | appinfo -- reads the metadata of the app file passed in.  
  Templates -- some template programs to get started with
  README.md -- This file

To complete this you will need one more thing, vsruntime.base from the releases page(wherever you got this SDK from). Then put it in the include folder of the app template and you are good to go.
